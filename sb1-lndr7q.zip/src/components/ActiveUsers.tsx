import React from 'react';
import { User } from 'lucide-react';

interface ActiveUsersProps {
  users: Array<{
    id: string;
    name: string;
    lastActive: string;
  }>;
}

export default function ActiveUsers({ users }: ActiveUsersProps) {
  const activeUsers = users.filter(user => {
    const lastActive = new Date(user.lastActive);
    const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
    return lastActive > fiveMinutesAgo;
  });

  if (activeUsers.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 bg-white rounded-lg shadow-lg p-3 border">
      <div className="flex items-center gap-2 mb-2">
        <User size={16} className="text-gray-500" />
        <span className="text-sm font-medium">Utilisateurs actifs</span>
      </div>
      <div className="space-y-1">
        {activeUsers.map(user => (
          <div key={user.id} className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-600">{user.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
}