import { useState, useEffect } from 'react';
import { useApi } from './useApi';
import { Reception } from '../types';
import { useOfflineSync } from './useOfflineSync';

export function useSync() {
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const api = useApi();
  const { db, isOnline } = useOfflineSync();

  const syncWithServer = async () => {
    if (!isOnline || !db || isSyncing) return;

    try {
      setIsSyncing(true);

      // Récupérer les modifications locales
      const queue = await db.getSyncQueue();
      
      // Synchroniser avec le serveur
      for (const item of queue) {
        try {
          switch (item.action) {
            case 'add':
              await api.post('/api/receptions', item.data);
              break;
            case 'update':
              await api.put(`/api/receptions/${item.data.id}`, item.data);
              break;
            case 'delete':
              await api.delete(`/api/receptions/${item.data.id}`);
              break;
          }
        } catch (error) {
          console.error('Sync error:', error);
          return; // Arrêter la synchronisation en cas d'erreur
        }
      }

      // Récupérer les dernières données du serveur
      const serverReceptions = await api.get('/api/receptions');
      
      // Mettre à jour la base de données locale
      await db.clearReceptions();
      for (const reception of serverReceptions) {
        await db.addReception(reception);
      }

      // Vider la file d'attente
      await db.clearSyncQueue();
      
      setLastSync(new Date());
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  // Synchroniser automatiquement quand la connexion est rétablie
  useEffect(() => {
    if (isOnline) {
      syncWithServer();
    }
  }, [isOnline]);

  return {
    isSyncing,
    lastSync,
    syncWithServer
  };
}