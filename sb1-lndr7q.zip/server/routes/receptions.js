import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function receptionRoutes(fastify) {
  // Récupérer toutes les réceptions
  fastify.get('/api/receptions', async (request, reply) => {
    try {
      const receptions = await prisma.reception.findMany({
        where: { companyId: request.user.companyId },
        orderBy: { date: 'asc' }
      });
      return receptions;
    } catch (error) {
      console.error('Error fetching receptions:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });

  // Créer une nouvelle réception
  fastify.post('/api/receptions', async (request, reply) => {
    const { date, hour, minutes, transporteur, reference, position } = request.body;

    try {
      const reception = await prisma.reception.create({
        data: {
          date: new Date(date),
          hour,
          minutes,
          transporteur,
          reference,
          position,
          status: 'pending',
          companyId: request.user.companyId,
          createdById: request.user.id
        }
      });
      return reception;
    } catch (error) {
      console.error('Error creating reception:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });

  // Mettre à jour une réception
  fastify.patch('/api/receptions/:id', async (request, reply) => {
    const { id } = request.params;
    const updates = request.body;

    try {
      const reception = await prisma.reception.update({
        where: { 
          id,
          companyId: request.user.companyId
        },
        data: {
          ...updates,
          modifiedById: request.user.id,
          modifiedAt: new Date()
        }
      });
      return reception;
    } catch (error) {
      console.error('Error updating reception:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });

  // Supprimer une réception
  fastify.delete('/api/receptions/:id', async (request, reply) => {
    const { id } = request.params;

    try {
      await prisma.reception.delete({
        where: { 
          id,
          companyId: request.user.companyId
        }
      });
      return { success: true };
    } catch (error) {
      console.error('Error deleting reception:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });
}