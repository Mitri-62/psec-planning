import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Calendar, Search, Bell, User } from 'lucide-react';
import ThemeToggle from './ThemeToggle';

interface HeaderProps {
  user: User;
  onSearch: (query: string) => void;
  unreadNotifications: number;
}

export default function Header({ user, onSearch, unreadNotifications }: HeaderProps) {
  const location = useLocation();
  const isPlanning = location.pathname === '/planning';

  return (
    <div className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="text-xl font-bold text-gray-900 dark:text-white">
              PSEC
            </Link>
          </div>

          <div className="flex-1 max-w-lg mx-8">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder={isPlanning ? "Rechercher un transporteur, une référence..." : "Rechercher..."}
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                onChange={(e) => onSearch(e.target.value)}
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <ThemeToggle />
            
            {!isPlanning && (
              <Link
                to="/planning"
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Calendar size={20} />
                <span>Planning</span>
              </Link>
            )}

            <button className="relative p-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white">
              <Bell size={20} />
              {unreadNotifications > 0 && (
                <span className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {unreadNotifications}
                </span>
              )}
            </button>

            <div className="flex items-center gap-2 text-sm">
              <div className="w-8 h-8 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center">
                <User size={20} className="text-gray-600 dark:text-gray-300" />
              </div>
              <div>
                <div className="font-medium text-gray-900 dark:text-white">{user.name}</div>
                <div className="text-xs text-gray-500 dark:text-gray-400 capitalize">{user.role}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}