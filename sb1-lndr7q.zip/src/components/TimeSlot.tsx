import React from 'react';
import { Check, Clock, Truck } from 'lucide-react';
import { Reception } from '../types';

interface TimeSlotProps {
  hour: number;
  reception?: Reception;
  onAddReception: (hour: number) => void;
  onConfirm: (id: string) => void;
}

export default function TimeSlot({ hour, reception, onAddReception, onConfirm }: TimeSlotProps) {
  const getStatusColor = (status: Reception['status']) => {
    switch (status) {
      case 'confirmed':
        return 'bg-blue-100 border-blue-300';
      case 'completed':
        return 'bg-green-100 border-green-300';
      default:
        return 'bg-yellow-50 border-yellow-200';
    }
  };

  return (
    <div 
      className={`p-3 border rounded-lg ${
        reception 
          ? getStatusColor(reception.status)
          : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
      } transition-colors`}
      onClick={() => !reception && onAddReception(hour)}
    >
      <div className="flex items-center justify-between mb-1">
        <span className="font-medium">{hour}:00</span>
        {reception && (
          <div className="flex gap-2">
            {reception.status === 'pending' && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onConfirm(reception.id);
                }}
                className="text-blue-600 hover:text-blue-800"
              >
                <Check size={18} />
              </button>
            )}
            {reception.status === 'confirmed' && <Clock size={18} className="text-blue-600" />}
            {reception.status === 'completed' && <Check size={18} className="text-green-600" />}
          </div>
        )}
      </div>
      
      {reception && (
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Truck size={16} className="text-gray-600" />
            <span className="text-sm font-medium">{reception.transporteur}</span>
          </div>
          <div className="text-xs text-gray-600">Ref: {reception.reference}</div>
          {reception.notes && (
            <div className="text-xs text-gray-500 italic">{reception.notes}</div>
          )}
        </div>
      )}
    </div>
  );
}