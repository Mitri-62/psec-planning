import React from 'react';
import { Trash2 } from 'lucide-react';
import { User } from '../types';

interface TeamProps {
  users: User[];
  onDeleteUser: (id: string) => void;
  currentUser: User;
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

function getRandomColor(name: string): string {
  const colors = [
    'bg-blue-100 text-blue-600',
    'bg-green-100 text-green-600',
    'bg-purple-100 text-purple-600',
    'bg-yellow-100 text-yellow-600',
    'bg-pink-100 text-pink-600',
    'bg-indigo-100 text-indigo-600',
  ];
  
  // Utiliser la somme des codes ASCII des caractères du nom pour choisir une couleur
  const sum = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[sum % colors.length];
}

export default function Team({ users, onDeleteUser, currentUser }: TeamProps) {
  const canDeleteUser = currentUser.role === 'admin';

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Gestion de l'équipe</h1>
        </div>

        <div className="bg-white rounded-xl shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
            {users.map((user) => (
              <div
                key={user.id}
                className="p-4 border rounded-lg bg-gray-50 flex items-start justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${getRandomColor(user.name)}`}>
                    {getInitials(user.name)}
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{user.name}</h3>
                    <p className="text-sm text-gray-500 capitalize">{user.role}</p>
                    <p className="text-xs text-gray-400">{user.email}</p>
                    {user.lastActive && (
                      <p className="text-xs text-gray-400">
                        Dernière activité: {new Date(user.lastActive).toLocaleDateString('fr-FR')}
                      </p>
                    )}
                  </div>
                </div>
                {canDeleteUser && currentUser.id !== user.id && (
                  <button
                    onClick={() => {
                      if (window.confirm(`Êtes-vous sûr de vouloir supprimer ${user.name} ?`)) {
                        onDeleteUser(user.id);
                      }
                    }}
                    className="p-1 text-gray-400 hover:text-red-600"
                    title="Supprimer"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}