export interface Reception {
  id: string;
  date: string;
  hour: number;
  minutes: number;
  transporteur: string;
  reference?: string;
  status: 'pending' | 'confirmed' | 'delayed' | 'completed';
  notes?: string;
  position: number;
  expectedTime?: string;
  modifiedBy?: string;
  modifiedAt?: string;
  createdBy?: string;
  createdAt: string;
}

export interface DashboardStats {
  confirmed: number;
  pending: number;
  delayed: number;
  todayTotal: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  lastActive?: string;
}

export interface LoadingState {
  isLoading: boolean;
  error: string | null;
}