import React, { useMemo } from 'react';
import { BarChart3, Download, Calendar } from 'lucide-react';
import { Reception } from '../types';

interface ReportsProps {
  receptions: Reception[];
}

export default function Reports({ receptions }: ReportsProps) {
  const currentMonth = new Date().toISOString().slice(0, 7);
  const [selectedMonth, setSelectedMonth] = React.useState(currentMonth);

  const monthlyStats = useMemo(() => {
    const filtered = receptions.filter(r => 
      r.date.startsWith(selectedMonth)
    );

    const transporteurs = [...new Set(filtered.map(r => r.transporteur))];
    const stats = transporteurs.map(transporteur => {
      const transporteurReceptions = filtered.filter(r => r.transporteur === transporteur);
      return {
        transporteur,
        total: transporteurReceptions.length,
        onTime: transporteurReceptions.filter(r => r.status === 'completed').length,
        delayed: transporteurReceptions.filter(r => r.status === 'delayed').length,
        punctualityRate: transporteurReceptions.length > 0
          ? Math.round((transporteurReceptions.filter(r => r.status === 'completed').length / transporteurReceptions.length) * 100)
          : 0
      };
    });

    return stats.sort((a, b) => b.total - a.total);
  }, [receptions, selectedMonth]);

  const exportReport = () => {
    const csvContent = [
      ['Transporteur', 'Total', 'À l\'heure', 'En retard', 'Taux de ponctualité'].join(','),
      ...monthlyStats.map(stat => [
        stat.transporteur,
        stat.total,
        stat.onTime,
        stat.delayed,
        `${stat.punctualityRate}%`
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `rapport_${selectedMonth}.csv`;
    link.click();
  };

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              <span className="flex items-center gap-2">
                <BarChart3 size={28} />
                Rapports Mensuels
              </span>
            </h1>
            <div className="flex items-center gap-2 bg-white dark:bg-gray-800 rounded-lg shadow-sm border dark:border-gray-700 p-2">
              <Calendar size={20} className="text-gray-500 dark:text-gray-400" />
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="border-0 bg-transparent focus:ring-0 dark:text-white"
              />
            </div>
          </div>
          <button
            onClick={exportReport}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          >
            <Download size={20} />
            <span>Exporter</span>
          </button>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b dark:border-gray-700">
                  <th className="py-3 text-left text-gray-900 dark:text-white">Transporteur</th>
                  <th className="py-3 text-left text-gray-900 dark:text-white">Total</th>
                  <th className="py-3 text-left text-gray-900 dark:text-white">À l'heure</th>
                  <th className="py-3 text-left text-gray-900 dark:text-white">En retard</th>
                  <th className="py-3 text-left text-gray-900 dark:text-white">Ponctualité</th>
                </tr>
              </thead>
              <tbody>
                {monthlyStats.map((stat) => (
                  <tr key={stat.transporteur} className="border-b dark:border-gray-700">
                    <td className="py-3 text-gray-900 dark:text-white font-medium">
                      {stat.transporteur}
                    </td>
                    <td className="py-3 text-gray-900 dark:text-white">{stat.total}</td>
                    <td className="py-3">
                      <span className="text-green-600 dark:text-green-400">{stat.onTime}</span>
                    </td>
                    <td className="py-3">
                      <span className="text-red-600 dark:text-red-400">{stat.delayed}</span>
                    </td>
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-600"
                            style={{ width: `${stat.punctualityRate}%` }}
                          />
                        </div>
                        <span className="text-gray-900 dark:text-white">
                          {stat.punctualityRate}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
                {monthlyStats.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-gray-500 dark:text-gray-400">
                      Aucune donnée disponible pour ce mois
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}