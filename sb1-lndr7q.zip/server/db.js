import { createClient } from '@libsql/client';
import dotenv from 'dotenv';

dotenv.config();

const db = createClient({
  url: process.env.DATABASE_URL,
  authToken: process.env.DATABASE_AUTH_TOKEN
});

async function initializeDB() {
  await db.execute(`
    CREATE TABLE IF NOT EXISTS companies (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      name TEXT NOT NULL,
      role TEXT NOT NULL,
      company_id TEXT NOT NULL,
      last_active DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (company_id) REFERENCES companies (id)
    );

    CREATE TABLE IF NOT EXISTS receptions (
      id TEXT PRIMARY KEY,
      date TEXT NOT NULL,
      hour INTEGER NOT NULL,
      minutes INTEGER NOT NULL,
      transporteur TEXT NOT NULL,
      reference TEXT,
      status TEXT NOT NULL,
      notes TEXT,
      position INTEGER NOT NULL,
      company_id TEXT NOT NULL,
      created_by_id TEXT NOT NULL,
      modified_by_id TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      modified_at DATETIME,
      FOREIGN KEY (company_id) REFERENCES companies (id),
      FOREIGN KEY (created_by_id) REFERENCES users (id),
      FOREIGN KEY (modified_by_id) REFERENCES users (id)
    );
  `);

  return db;
}

export default await initializeDB();