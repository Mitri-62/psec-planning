import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Planning from './pages/Planning';
import History from './pages/History';
import Team from './pages/Team';
import Reports from './pages/Reports';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Auth from './components/Auth';
import { Reception, User } from './types';
import { useOfflineSync } from './hooks/useOfflineSync';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [receptions, setReceptions] = useState<Reception[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [transporters, setTransporters] = useState<string[]>(() => {
    const saved = localStorage.getItem('transporters');
    return saved ? JSON.parse(saved) : ['NSF', 'MAZET', 'LINEAGE', 'FRAISE', 'RHUM RAISAIN'];
  });

  const { isOnline, db } = useOfflineSync();

  useEffect(() => {
    // Charger les utilisateurs existants
    const savedUsers = localStorage.getItem('users');
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    }

    // Vérifier si un utilisateur est déjà connecté
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setCurrentUser(user);
      setIsAuthenticated(true);
    }

    // Charger les réceptions depuis IndexedDB
    if (db) {
      db.getReceptions().then(setReceptions).catch(console.error);
    }
  }, [db]);

  // Sauvegarder les transporteurs dans le localStorage
  useEffect(() => {
    localStorage.setItem('transporters', JSON.stringify(transporters));
  }, [transporters]);

  const handleLogin = (user: User) => {
    setUsers(prevUsers => {
      const existingUser = prevUsers.find(u => u.email === user.email);
      if (!existingUser) {
        const newUsers = [...prevUsers, user];
        localStorage.setItem('users', JSON.stringify(newUsers));
        return newUsers;
      }
      return prevUsers;
    });

    localStorage.setItem('currentUser', JSON.stringify(user));
    setCurrentUser(user);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    setCurrentUser(null);
    setIsAuthenticated(false);
  };

  const handleAddReception = async (reception: Omit<Reception, 'id' | 'createdAt' | 'createdBy'>) => {
    const newReception: Reception = {
      id: Date.now().toString(),
      ...reception,
      createdAt: new Date().toISOString(),
      createdBy: currentUser?.id || 'anonymous',
    };

    if (db) {
      await db.addReception(newReception);
      setReceptions(prev => [...prev, newReception]);
    }
  };

  const handleUpdateReception = async (id: string, updates: Partial<Reception>) => {
    if (db) {
      await db.updateReception(id, updates);
      setReceptions(prev => prev.map(r => 
        r.id === id ? { ...r, ...updates } : r
      ));
    }
  };

  const handleDeleteReception = async (id: string) => {
    if (db) {
      await db.deleteReception(id);
      setReceptions(prev => prev.filter(r => r.id !== id));
    }
  };

  const handleDeleteUser = (id: string) => {
    setUsers(prevUsers => {
      const newUsers = prevUsers.filter(user => user.id !== id);
      localStorage.setItem('users', JSON.stringify(newUsers));
      return newUsers;
    });
  };

  const handleAddTransporter = (name: string) => {
    setTransporters(prev => {
      const newTransporters = [...prev, name].sort();
      localStorage.setItem('transporters', JSON.stringify(newTransporters));
      return newTransporters;
    });
  };

  const handleDeleteTransporter = (name: string) => {
    setTransporters(prev => {
      const newTransporters = prev.filter(t => t !== name);
      localStorage.setItem('transporters', JSON.stringify(newTransporters));
      return newTransporters;
    });
  };

  const filteredReceptions = receptions.filter(reception => {
    const searchLower = searchQuery.toLowerCase();
    return (
      reception.transporteur.toLowerCase().includes(searchLower) ||
      (reception.reference?.toLowerCase().includes(searchLower)) ||
      (reception.notes?.toLowerCase().includes(searchLower))
    );
  });

  if (!isAuthenticated || !currentUser) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <BrowserRouter>
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar 
          user={currentUser} 
          onLogout={handleLogout} 
          transporters={transporters}
          onAddTransporter={handleAddTransporter}
          onDeleteTransporter={handleDeleteTransporter}
        />
        <div className="flex-1">
          <Header 
            user={currentUser}
            onSearch={setSearchQuery}
            unreadNotifications={0}
          />
          <Routes>
            <Route 
              path="/" 
              element={
                <Dashboard 
                  receptions={filteredReceptions}
                  onUpdateNote={(id, note) => handleUpdateReception(id, { notes: note })}
                />
              } 
            />
            <Route
              path="/planning"
              element={
                <Planning
                  receptions={filteredReceptions}
                  transporters={transporters}
                  onAddReception={handleAddReception}
                  onUpdateStatus={(id, status) => handleUpdateReception(id, { status })}
                  onUpdateNote={(id, note) => handleUpdateReception(id, { notes: note })}
                  onDeleteReception={handleDeleteReception}
                />
              }
            />
            <Route
              path="/history"
              element={
                <History
                  receptions={filteredReceptions}
                />
              }
            />
            <Route
              path="/team"
              element={
                <Team
                  users={users}
                  onDeleteUser={handleDeleteUser}
                  currentUser={currentUser}
                />
              }
            />
            <Route
              path="/reports"
              element={
                <Reports
                  receptions={filteredReceptions}
                />
              }
            />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}