import { useState, useEffect } from 'react';
import { Reception } from '../types';

export function useReceptions() {
  const [receptions, setReceptions] = useState<Reception[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const addReception = (reception: Omit<Reception, 'id' | 'createdAt' | 'createdBy'>) => {
    const newReception: Reception = {
      id: Date.now().toString(),
      ...reception,
      createdAt: new Date().toISOString(),
      createdBy: 'user-1', // Temporary mock user ID
    };
    setReceptions(prev => [...prev, newReception]);
  };

  const updateReception = (id: string, updates: Partial<Reception>) => {
    setReceptions(prev =>
      prev.map(reception =>
        reception.id === id
          ? { ...reception, ...updates }
          : reception
      )
    );
  };

  return {
    receptions,
    isLoading,
    error,
    addReception,
    updateReception
  };
}