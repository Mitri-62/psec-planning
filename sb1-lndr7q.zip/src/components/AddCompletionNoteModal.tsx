import React, { useState } from 'react';
import { X } from 'lucide-react';

interface AddCompletionNoteModalProps {
  receptionId: string;
  currentNote?: string;
  onClose: () => void;
  onSave: (id: string, note: string) => void;
}

export default function AddCompletionNoteModal({
  receptionId,
  currentNote = '',
  onClose,
  onSave,
}: AddCompletionNoteModalProps) {
  const [note, setNote] = useState(currentNote);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(receptionId, note);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Ajouter une note de réception</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Note (état des palettes, problèmes, etc.)
            </label>
            <textarea
              className="w-full p-2 border rounded-md"
              rows={4}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ex: 3 palettes endommagées..."
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}