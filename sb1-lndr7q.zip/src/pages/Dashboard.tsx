import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, CheckCircle } from 'lucide-react';
import DashboardCard from '../components/DashboardCard';
import { Reception } from '../types';

interface DashboardProps {
  receptions: Reception[];
  onUpdateNote: (id: string, note: string) => void;
}

const getStatusLabel = (status: Reception['status']) => {
  switch (status) {
    case 'confirmed':
      return 'Confirmée';
    case 'delayed':
      return 'En retard';
    case 'pending':
      return 'En attente';
    default:
      return 'Terminée';
  }
};

const getStatusStyle = (status: Reception['status']) => {
  switch (status) {
    case 'confirmed':
      return 'bg-green-50 border-l-4 border-l-green-500';
    case 'delayed':
      return 'bg-red-50 border-l-4 border-l-red-500';
    case 'pending':
      return 'bg-yellow-50 border-l-4 border-l-yellow-500';
    default:
      return 'bg-blue-50 border-l-4 border-l-blue-500';
  }
};

const getStatusTextStyle = (status: Reception['status']) => {
  switch (status) {
    case 'confirmed':
      return 'text-green-700';
    case 'delayed':
      return 'text-red-700';
    case 'pending':
      return 'text-yellow-700';
    default:
      return 'text-blue-700';
  }
};

export default function Dashboard({ receptions, onUpdateNote }: DashboardProps) {
  const today = new Date().toISOString().split('T')[0];
  const currentHour = new Date().getHours();

  // Filtrer les réceptions du jour et trier par heure et minutes
  const todayReceptions = receptions
    .filter(r => r.date === today)
    .sort((a, b) => {
      // Trier d'abord par heure
      if (a.hour !== b.hour) {
        return a.hour - b.hour;
      }
      // Si même heure, trier par minutes
      return (a.minutes || 0) - (b.minutes || 0);
    });

  // Filtrer les réceptions à partir de l'heure actuelle
  const upcomingReceptions = todayReceptions.filter(r => r.hour >= currentHour);

  // Trouver la dernière réception confirmée
  const lastConfirmedReception = [...todayReceptions]
    .reverse()
    .find(r => r.status === 'confirmed');

  const stats = {
    confirmed: todayReceptions.filter(r => r.status === 'confirmed').length,
    pending: todayReceptions.filter(r => r.status === 'pending').length,
    delayed: todayReceptions.filter(r => r.status === 'delayed').length,
    todayTotal: todayReceptions.length
  };

  const completedReceptions = todayReceptions.filter(r => 
    r.status === 'confirmed' || r.status === 'completed'
  ).length;
  const punctualityRate = todayReceptions.length > 0
    ? Math.round((completedReceptions / todayReceptions.length) * 100)
    : 0;

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Tableau de Bord PSEC</h1>
          <Link
            to="/planning"
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Calendar size={20} />
            <span>Voir le Planning</span>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          <DashboardCard
            title="Total Aujourd'hui"
            value={stats.todayTotal}
            type="total"
          />
          <DashboardCard
            title="En Attente"
            value={stats.pending}
            type="pending"
          />
          <DashboardCard
            title="Confirmées"
            value={stats.confirmed}
            type="confirmed"
          />
          <DashboardCard
            title="En Retard"
            value={stats.delayed}
            type="delayed"
          />
          <DashboardCard
            title="Taux de Ponctualité"
            value={punctualityRate}
            type="punctuality"
            unit="%"
          />
        </div>

        {lastConfirmedReception && (
          <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
            <div className="flex items-center gap-2 p-4 border-b bg-green-50">
              <CheckCircle size={20} className="text-green-600" />
              <h2 className="text-xl font-semibold text-gray-900">
                Dernière Réception Confirmée
              </h2>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Heure</p>
                  <p className="font-medium">
                    {lastConfirmedReception.hour}h
                    {lastConfirmedReception.minutes?.toString().padStart(2, '0') || '00'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Transporteur</p>
                  <p className="font-medium">{lastConfirmedReception.transporteur}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Référence</p>
                  <p className="font-medium">{lastConfirmedReception.reference || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Notes</p>
                  <p className="font-medium">{lastConfirmedReception.notes || '-'}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <h2 className="text-xl font-semibold p-6 border-b">
            Réceptions à venir aujourd'hui
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="py-3 px-6 text-left text-gray-600">Heure</th>
                  <th className="py-3 px-6 text-left text-gray-600">Transporteur</th>
                  <th className="py-3 px-6 text-left text-gray-600">Référence</th>
                  <th className="py-3 px-6 text-left text-gray-600">Statut</th>
                  <th className="py-3 px-6 text-left text-gray-600">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {upcomingReceptions.map(reception => (
                  <tr 
                    key={reception.id} 
                    className={`${getStatusStyle(reception.status)} transition-colors hover:bg-opacity-80`}
                  >
                    <td className="py-4 px-6">
                      {reception.hour}h{reception.minutes ? reception.minutes.toString().padStart(2, '0') : '00'}
                    </td>
                    <td className="py-4 px-6 font-medium">{reception.transporteur}</td>
                    <td className="py-4 px-6">{reception.reference || '-'}</td>
                    <td className="py-4 px-6">
                      <span className={`font-medium ${getStatusTextStyle(reception.status)}`}>
                        {getStatusLabel(reception.status)}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      {reception.notes ? (
                        <span className="text-gray-600">{reception.notes}</span>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                  </tr>
                ))}
                {upcomingReceptions.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-gray-500">
                      Aucune réception prévue pour le reste de la journée
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}