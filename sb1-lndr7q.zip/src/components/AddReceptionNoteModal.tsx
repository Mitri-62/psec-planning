import React, { useState } from 'react';
import { X } from 'lucide-react';
import { Reception } from '../types';

interface AddReceptionNoteModalProps {
  reception: Reception;
  onClose: () => void;
  onSave: (note: string) => void;
}

export default function AddReceptionNoteModal({
  reception,
  onClose,
  onSave,
}: AddReceptionNoteModalProps) {
  const [note, setNote] = useState(reception.notes || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(note);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">
            Note - {reception.transporteur} ({reception.reference})
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Note
            </label>
            <textarea
              className="w-full p-2 border rounded-md"
              rows={4}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ajouter une note..."
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Enregistrer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}