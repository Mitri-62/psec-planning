import React from 'react';
import { Clock, CheckCircle, AlertTriangle, Truck, Percent } from 'lucide-react';

interface DashboardCardProps {
  title: string;
  value: number;
  type: 'confirmed' | 'pending' | 'delayed' | 'total' | 'punctuality';
  unit?: string;
}

export default function DashboardCard({ title, value, type, unit }: DashboardCardProps) {
  const getIcon = () => {
    switch (type) {
      case 'confirmed':
        return <CheckCircle className="text-green-500" size={24} />;
      case 'delayed':
        return <AlertTriangle className="text-red-500" size={24} />;
      case 'pending':
        return <Clock className="text-yellow-500" size={24} />;
      case 'punctuality':
        return <Percent className="text-indigo-500" size={24} />;
      default:
        return <Truck className="text-gray-500" size={24} />;
    }
  };

  const getColor = () => {
    switch (type) {
      case 'confirmed':
        return 'bg-green-50 border-green-200';
      case 'delayed':
        return 'bg-red-50 border-red-200';
      case 'pending':
        return 'bg-yellow-50 border-yellow-200';
      case 'punctuality':
        return 'bg-indigo-50 border-indigo-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className={`p-6 rounded-lg border ${getColor()}`}>
      <div className="flex items-center gap-4">
        {getIcon()}
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
          <p className="text-3xl font-bold mt-1">
            {value}
            {unit && <span className="text-xl ml-1">{unit}</span>}
          </p>
        </div>
      </div>
    </div>
  );
}