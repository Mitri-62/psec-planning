import React from 'react';
import { Filter } from 'lucide-react';

interface FiltersProps {
  onFilterChange: (filters: {
    status?: string[];
    transporteur?: string[];
    dateRange?: [Date, Date];
  }) => void;
}

export default function Filters({ onFilterChange }: FiltersProps) {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border mb-4">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Filter size={20} className="text-gray-500" />
          <span className="font-medium">Filtres</span>
        </div>

        <select
          className="px-3 py-1.5 border rounded-md text-sm"
          onChange={(e) => onFilterChange({ status: [e.target.value] })}
          defaultValue=""
        >
          <option value="">Tous les statuts</option>
          <option value="pending">En attente</option>
          <option value="confirmed">Confirmées</option>
          <option value="delayed">En retard</option>
          <option value="completed">Terminées</option>
        </select>

        <select
          className="px-3 py-1.5 border rounded-md text-sm"
          onChange={(e) => onFilterChange({ transporteur: [e.target.value] })}
          defaultValue=""
        >
          <option value="">Tous les transporteurs</option>
          <option value="NSF">NSF</option>
          <option value="MAZET">MAZET</option>
          <option value="LINEAGE">LINEAGE</option>
          <option value="FRAISE">FRAISE</option>
          <option value="RHUM RAISAIN">RHUM RAISAIN</option>
        </select>

        <button
          onClick={() => onFilterChange({})}
          className="text-sm text-blue-600 hover:text-blue-800"
        >
          Réinitialiser
        </button>
      </div>
    </div>
  );
}