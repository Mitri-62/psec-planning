import jwt from 'jsonwebtoken';
import db from '../db.js';

export async function authenticate(request, reply) {
  try {
    const token = request.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      throw new Error('No token provided');
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await db.get(
      `SELECT id, email, role, company_id as companyId
       FROM users 
       WHERE id = ?`,
      [decoded.id]
    );

    if (!user) {
      throw new Error('User not found');
    }

    request.user = user;
  } catch (error) {
    reply.code(401).send({ error: 'Please authenticate' });
  }
}