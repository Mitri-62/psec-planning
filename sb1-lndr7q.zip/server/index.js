import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import { authRoutes } from './routes/auth.js';
import { receptionRoutes } from './routes/receptions.js';
import { userRoutes } from './routes/users.js';
import { healthRoutes } from './routes/health.js';
import { authenticate } from './middleware/auth.js';

dotenv.config();

const fastify = Fastify({ 
  logger: true,
  trustProxy: true
});

// CORS
await fastify.register(cors, {
  origin: true,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
});

// Authentication middleware for protected routes
fastify.addHook('onRequest', async (request, reply) => {
  if (request.url.startsWith('/api') && !request.url.startsWith('/api/auth')) {
    await authenticate(request, reply);
  }
});

// Routes
fastify.register(authRoutes);
fastify.register(receptionRoutes);
fastify.register(userRoutes);
fastify.register(healthRoutes);

// Start server
const start = async () => {
  try {
    const port = parseInt(process.env.PORT || '3000', 10);
    const host = process.env.HOST || 'localhost';
    
    await fastify.listen({ port, host });
    console.log(`Server running at http://${host}:${port}`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

start();