import { config } from '../config';

interface ApiOptions {
  method?: string;
  body?: any;
  headers?: Record<string, string>;
}

export function useApi() {
  const token = localStorage.getItem('token');

  const fetchApi = async (endpoint: string, options: ApiOptions = {}) => {
    try {
      const response = await fetch(`${config.apiUrl}${endpoint}`, {
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token ? `Bearer ${token}` : '',
          ...options.headers,
        },
        body: options.body ? JSON.stringify(options.body) : undefined,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Une erreur est survenue');
      }

      return await response.json();
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  };

  return {
    get: (endpoint: string) => fetchApi(endpoint),
    post: (endpoint: string, data: any) => fetchApi(endpoint, { 
      method: 'POST', 
      body: data 
    }),
    put: (endpoint: string, data: any) => fetchApi(endpoint, { 
      method: 'PUT', 
      body: data 
    }),
    delete: (endpoint: string) => fetchApi(endpoint, { 
      method: 'DELETE' 
    }),
  };
}