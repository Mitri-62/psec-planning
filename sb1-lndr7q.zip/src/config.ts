const getApiUrl = () => {
  if (import.meta.env.VITE_API_URL) {
    return import.meta.env.VITE_API_URL;
  }
  
  // En développement, utiliser localhost
  if (import.meta.env.DEV) {
    return 'http://localhost:3000';
  }
  
  // En production, utiliser l'URL Railway ou Render
  return 'https://psec-planning.onrender.com';
};

export const config = {
  apiUrl: getApiUrl(),
};