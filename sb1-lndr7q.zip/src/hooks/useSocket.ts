import { useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { config } from '../config';
import { Reception } from '../types';

interface ServerToClientEvents {
  'reception:added': (reception: Reception) => void;
  'reception:updated': (reception: Reception) => void;
  'reception:deleted': (id: string) => void;
  'user:active': (userId: string) => void;
}

interface ClientToServerEvents {
  'reception:add': (reception: Omit<Reception, 'id' | 'createdAt' | 'createdBy'>) => void;
  'reception:update': (id: string, updates: Partial<Reception>) => void;
  'reception:delete': (id: string) => void;
}

export function useSocket(token: string) {
  const socketRef = useRef<Socket<ServerToClientEvents, ClientToServerEvents>>();
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  useEffect(() => {
    if (!socketRef.current) {
      socketRef.current = io(config.wsUrl, {
        auth: { token },
        path: '/ws',
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionAttempts: maxReconnectAttempts,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        timeout: 30000,
        forceNew: true,
        autoConnect: true
      });

      socketRef.current.on('connect_error', (error) => {
        console.error('Socket connection error:', error.message);
        reconnectAttempts.current++;

        if (reconnectAttempts.current >= maxReconnectAttempts) {
          console.error('Maximum reconnection attempts reached');
          socketRef.current?.disconnect();
        }
      });

      socketRef.current.on('connect', () => {
        console.log('Socket connection established');
        reconnectAttempts.current = 0;
      });

      socketRef.current.on('disconnect', (reason) => {
        console.log('Socket disconnected:', reason);
        if (reason === 'io server disconnect') {
          // Server initiated disconnect, try to reconnect
          socketRef.current?.connect();
        }
      });

      // Ping/Pong to keep connection alive
      const pingInterval = setInterval(() => {
        if (socketRef.current?.connected) {
          socketRef.current.emit('ping');
        }
      }, 25000);

      return () => {
        clearInterval(pingInterval);
        if (socketRef.current) {
          socketRef.current.disconnect();
          socketRef.current = undefined;
        }
      };
    }
  }, [token]);

  const subscribeToReceptions = (callbacks: {
    onReceptionAdded: (reception: Reception) => void;
    onReceptionUpdated: (reception: Reception) => void;
    onReceptionDeleted: (id: string) => void;
    onUserActive: (userId: string) => void;
  }) => {
    if (!socketRef.current) return;

    socketRef.current.on('reception:added', callbacks.onReceptionAdded);
    socketRef.current.on('reception:updated', callbacks.onReceptionUpdated);
    socketRef.current.on('reception:deleted', callbacks.onReceptionDeleted);
    socketRef.current.on('user:active', callbacks.onUserActive);

    return () => {
      if (socketRef.current) {
        socketRef.current.off('reception:added');
        socketRef.current.off('reception:updated');
        socketRef.current.off('reception:deleted');
        socketRef.current.off('user:active');
      }
    };
  };

  const emitReceptionAdd = (reception: Omit<Reception, 'id' | 'createdAt' | 'createdBy'>) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('reception:add', reception);
    }
  };

  const emitReceptionUpdate = (id: string, updates: Partial<Reception>) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('reception:update', id, updates);
    }
  };

  const emitReceptionDelete = (id: string) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('reception:delete', id);
    }
  };

  return {
    subscribeToReceptions,
    emitReceptionAdd,
    emitReceptionUpdate,
    emitReceptionDelete,
    isConnected: socketRef.current?.connected || false
  };
}