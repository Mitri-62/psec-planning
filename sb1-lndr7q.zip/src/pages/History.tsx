import React, { useState, useMemo } from 'react';
import { Calendar, Filter, Download } from 'lucide-react';
import { Reception } from '../types';

interface HistoryProps {
  receptions: Reception[];
}

type TimeRange = 'day' | 'week' | 'month' | 'year';

export default function History({ receptions }: HistoryProps) {
  const [timeRange, setTimeRange] = useState<TimeRange>('day');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  const filteredReceptions = useMemo(() => {
    const startDate = new Date(selectedDate);
    const endDate = new Date(selectedDate);

    switch (timeRange) {
      case 'week':
        startDate.setDate(startDate.getDate() - startDate.getDay());
        endDate.setDate(endDate.getDate() + (6 - endDate.getDay()));
        break;
      case 'month':
        startDate.setDate(1);
        endDate.setMonth(endDate.getMonth() + 1);
        endDate.setDate(0);
        break;
      case 'year':
        startDate.setMonth(0, 1);
        endDate.setMonth(11, 31);
        break;
      default:
        endDate.setHours(23, 59, 59, 999);
    }

    return receptions.filter(reception => {
      const receptionDate = new Date(reception.date);
      return receptionDate >= startDate && receptionDate <= endDate;
    });
  }, [receptions, selectedDate, timeRange]);

  const stats = useMemo(() => {
    return {
      total: filteredReceptions.length,
      onTime: filteredReceptions.filter(r => r.status === 'completed').length,
      delayed: filteredReceptions.filter(r => r.status === 'delayed').length,
      punctualityRate: filteredReceptions.length > 0
        ? Math.round((filteredReceptions.filter(r => r.status === 'completed').length / filteredReceptions.length) * 100)
        : 0
    };
  }, [filteredReceptions]);

  const handleExport = () => {
    const csvContent = [
      ['Date', 'Heure', 'Transporteur', 'Référence', 'Statut', 'Notes'].join(','),
      ...filteredReceptions.map(r => [
        new Date(r.date).toLocaleDateString('fr-FR'),
        `${r.hour}h${r.minutes?.toString().padStart(2, '0') || '00'}`,
        r.transporteur,
        r.reference || '',
        r.status,
        (r.notes || '').replace(/,/g, ';')
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `historique_receptions_${timeRange}_${selectedDate.toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold text-gray-900">Historique des Réceptions</h1>
            <div className="flex items-center gap-2 bg-white rounded-lg shadow-sm border p-2">
              <Calendar size={20} className="text-gray-500" />
              <input
                type="date"
                value={selectedDate.toISOString().split('T')[0]}
                onChange={(e) => setSelectedDate(new Date(e.target.value))}
                className="border-0 focus:ring-0"
              />
            </div>
          </div>
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          >
            <Download size={20} />
            <span>Exporter</span>
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Filter size={20} className="text-gray-500" />
              <div className="flex gap-2">
                {(['day', 'week', 'month', 'year'] as TimeRange[]).map((range) => (
                  <button
                    key={range}
                    onClick={() => setTimeRange(range)}
                    className={`px-4 py-2 rounded-lg ${
                      timeRange === range
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {range === 'day' && 'Jour'}
                    {range === 'week' && 'Semaine'}
                    {range === 'month' && 'Mois'}
                    {range === 'year' && 'Année'}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-6">
              <div className="text-center">
                <div className="text-sm text-gray-500">Total</div>
                <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-500">À l'heure</div>
                <div className="text-2xl font-bold text-green-600">{stats.onTime}</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-500">En retard</div>
                <div className="text-2xl font-bold text-red-600">{stats.delayed}</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-500">Ponctualité</div>
                <div className="text-2xl font-bold text-blue-600">{stats.punctualityRate}%</div>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="py-3 text-left">Date</th>
                  <th className="py-3 text-left">Heure</th>
                  <th className="py-3 text-left">Transporteur</th>
                  <th className="py-3 text-left">Référence</th>
                  <th className="py-3 text-left">Statut</th>
                  <th className="py-3 text-left">Notes</th>
                </tr>
              </thead>
              <tbody>
                {filteredReceptions.map((reception) => (
                  <tr key={reception.id} className="border-b hover:bg-gray-50">
                    <td className="py-3">
                      {new Date(reception.date).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="py-3">
                      {reception.hour}h{reception.minutes?.toString().padStart(2, '0') || '00'}
                    </td>
                    <td className="py-3">{reception.transporteur}</td>
                    <td className="py-3">{reception.reference || '-'}</td>
                    <td className="py-3">
                      <span
                        className={`px-2 py-1 rounded-full text-xs ${
                          reception.status === 'completed'
                            ? 'bg-green-100 text-green-800'
                            : reception.status === 'delayed'
                            ? 'bg-red-100 text-red-800'
                            : reception.status === 'confirmed'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {reception.status === 'completed' && 'Terminée'}
                        {reception.status === 'delayed' && 'En retard'}
                        {reception.status === 'confirmed' && 'Confirmée'}
                        {reception.status === 'pending' && 'En attente'}
                      </span>
                    </td>
                    <td className="py-3">
                      <div className="max-w-xs truncate">
                        {reception.notes || '-'}
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredReceptions.length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-gray-500">
                      Aucune réception trouvée pour cette période
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}