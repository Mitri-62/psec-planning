import React, { useState } from 'react';
import { Reception } from '../types';
import { Truck, AlertTriangle, MessageSquare, Undo2, Check, Plus, Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import AddReceptionNoteModal from './AddReceptionNoteModal';

interface TimeSlotGroupProps {
  hour: number;
  minutes: number;
  showLabel: boolean;
  receptions: Reception[];
  onAddReception: (hour: number, minutes: number, position: number) => void;
  onConfirm: (id: string) => void;
  onMarkDelayed: (id: string) => void;
  onMarkCompleted: (id: string) => void;
  onUpdateNote: (id: string, note: string) => void;
  onUpdateStatus: (id: string, status: Reception['status']) => void;
  onDeleteReception: (id: string) => void;
}

export default function TimeSlotGroup({
  hour,
  minutes,
  showLabel,
  receptions,
  onAddReception,
  onConfirm,
  onMarkDelayed,
  onMarkCompleted,
  onUpdateNote,
  onUpdateStatus,
  onDeleteReception
}: TimeSlotGroupProps) {
  const [selectedReception, setSelectedReception] = useState<Reception | null>(null);
  const [showAllSlots, setShowAllSlots] = useState(false);
  
  // Créer un tableau de 8 slots (au lieu de 4)
  const slots = Array.from({ length: 8 }, (_, i) => {
    return receptions.find(r => r.position === i + 1) || null;
  });

  // Diviser les slots en deux groupes : principaux (4 premiers) et additionnels
  const mainSlots = slots.slice(0, 4);
  const additionalSlots = slots.slice(4);
  const hasAdditionalReceptions = additionalSlots.some(slot => slot !== null);

  const getStatusColor = (status: Reception['status']) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-50 border-green-300';
      case 'completed':
        return 'bg-blue-50 border-blue-300';
      case 'delayed':
        return 'bg-red-50 border-red-300';
      default:
        return 'bg-yellow-50 border-yellow-200';
    }
  };

  const formatTime = (hour: number, minutes: number) => {
    return `${hour}h${minutes ? minutes.toString().padStart(2, '0') : '00'}`;
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cette réception ?')) {
      onDeleteReception(id);
    }
  };

  return (
    <>
      <div className="relative mt-6">
        {showLabel && (
          <div className="absolute -top-6 left-4 z-10">
            <div className="bg-gray-100 text-gray-700 px-4 py-1 rounded-t-lg font-medium border border-b-0 2xl:text-lg">
              {formatTime(hour, minutes)}
            </div>
          </div>
        )}
        
        <div className="bg-white rounded-lg border shadow-sm">
          <div className="flex-1 flex flex-col gap-2 p-3">
            {/* Slots principaux */}
            {mainSlots.map((reception, index) => (
              <div
                key={index}
                onClick={() => !reception && onAddReception(hour, minutes, index + 1)}
                className={`p-3 border rounded-lg transition-all ${
                  reception
                    ? `${getStatusColor(reception.status)} hover:shadow-md`
                    : 'bg-white hover:bg-blue-50 hover:border-blue-200 hover:shadow-md cursor-pointer group'
                }`}
              >
                {reception ? (
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Truck size={20} className="text-gray-600 flex-shrink-0" />
                        <span className="text-base 2xl:text-lg font-semibold truncate">
                          {reception.transporteur}
                        </span>
                      </div>
                      {reception.reference && (
                        <div className="text-xs 2xl:text-sm text-gray-600">
                          Ref: {reception.reference}
                        </div>
                      )}
                      {reception.notes && (
                        <div className="text-xs 2xl:text-sm text-gray-500 italic truncate">
                          {reception.notes}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      {reception.status === 'pending' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onConfirm(reception.id);
                          }}
                          className="p-1 text-green-600 hover:text-green-700"
                          title="Confirmer"
                        >
                          <Check size={18} />
                        </button>
                      )}
                      {reception.status !== 'completed' && reception.status !== 'delayed' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onMarkDelayed(reception.id);
                          }}
                          className="p-1 text-red-600 hover:text-red-700"
                          title="Marquer en retard"
                        >
                          <AlertTriangle size={18} />
                        </button>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedReception(reception);
                        }}
                        className="p-1 text-gray-600 hover:text-gray-700"
                        title="Ajouter une note"
                      >
                        <MessageSquare size={18} />
                      </button>
                      {reception.status !== 'pending' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onUpdateStatus(reception.id, 'pending');
                          }}
                          className="p-1 text-gray-600 hover:text-gray-700"
                          title="Retour en attente"
                        >
                          <Undo2 size={18} />
                        </button>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(reception.id);
                        }}
                        className="p-1 text-red-600 hover:text-red-700"
                        title="Supprimer"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="h-[72px] flex items-center justify-center text-gray-400 group-hover:text-blue-500">
                    <div className="flex flex-col items-center gap-1">
                      <Plus size={24} />
                      <span className="text-xs font-medium">Ajouter une réception</span>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {/* Bouton pour afficher/masquer les slots additionnels */}
            <button
              onClick={() => setShowAllSlots(!showAllSlots)}
              className="flex items-center justify-center gap-2 py-2 px-4 mt-2 text-sm bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-lg transition-colors"
            >
              {showAllSlots ? (
                <>
                  <ChevronUp size={18} />
                  <span>Masquer les réceptions supplémentaires</span>
                </>
              ) : (
                <>
                  <ChevronDown size={18} />
                  <span>
                    {hasAdditionalReceptions 
                      ? `Afficher plus de réceptions (${additionalSlots.filter(Boolean).length})`
                      : 'Ajouter plus de réceptions'}
                  </span>
                </>
              )}
            </button>

            {/* Slots additionnels */}
            {showAllSlots && additionalSlots.map((reception, index) => (
              <div
                key={index + 4}
                onClick={() => !reception && onAddReception(hour, minutes, index + 5)}
                className={`p-3 border rounded-lg transition-all ${
                  reception
                    ? `${getStatusColor(reception.status)} hover:shadow-md`
                    : 'bg-white hover:bg-blue-50 hover:border-blue-200 hover:shadow-md cursor-pointer group'
                }`}
              >
                {reception ? (
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Truck size={20} className="text-gray-600 flex-shrink-0" />
                        <span className="text-base 2xl:text-lg font-semibold truncate">
                          {reception.transporteur}
                        </span>
                      </div>
                      {reception.reference && (
                        <div className="text-xs 2xl:text-sm text-gray-600">
                          Ref: {reception.reference}
                        </div>
                      )}
                      {reception.notes && (
                        <div className="text-xs 2xl:text-sm text-gray-500 italic truncate">
                          {reception.notes}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      {reception.status === 'pending' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onConfirm(reception.id);
                          }}
                          className="p-1 text-green-600 hover:text-green-700"
                          title="Confirmer"
                        >
                          <Check size={18} />
                        </button>
                      )}
                      {reception.status !== 'completed' && reception.status !== 'delayed' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onMarkDelayed(reception.id);
                          }}
                          className="p-1 text-red-600 hover:text-red-700"
                          title="Marquer en retard"
                        >
                          <AlertTriangle size={18} />
                        </button>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedReception(reception);
                        }}
                        className="p-1 text-gray-600 hover:text-gray-700"
                        title="Ajouter une note"
                      >
                        <MessageSquare size={18} />
                      </button>
                      {reception.status !== 'pending' && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onUpdateStatus(reception.id, 'pending');
                          }}
                          className="p-1 text-gray-600 hover:text-gray-700"
                          title="Retour en attente"
                        >
                          <Undo2 size={18} />
                        </button>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(reception.id);
                        }}
                        className="p-1 text-red-600 hover:text-red-700"
                        title="Supprimer"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="h-[72px] flex items-center justify-center text-gray-400 group-hover:text-blue-500">
                    <div className="flex flex-col items-center gap-1">
                      <Plus size={24} />
                      <span className="text-xs font-medium">Ajouter une réception</span>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {selectedReception && (
        <AddReceptionNoteModal
          reception={selectedReception}
          onClose={() => setSelectedReception(null)}
          onSave={(note) => {
            onUpdateNote(selectedReception.id, note);
            setSelectedReception(null);
          }}
        />
      )}
    </>
  );
}