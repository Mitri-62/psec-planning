import React, { useState } from 'react';
import { X, Plus } from 'lucide-react';

interface AddReceptionModalProps {
  hour: number;
  minutes: number;
  date: string;
  transporters: string[];
  onClose: () => void;
  onAdd: (data: {
    transporteur: string;
    reference?: string;
    notes?: string;
  }) => void;
}

export default function AddReceptionModal({ 
  hour, 
  minutes, 
  date, 
  transporters,
  onClose, 
  onAdd 
}: AddReceptionModalProps) {
  const [formData, setFormData] = useState({
    transporteur: '',
    reference: '',
    notes: '',
  });
  const [showCustomInput, setShowCustomInput] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({
      ...formData,
      reference: formData.reference || undefined,
      notes: formData.notes || undefined,
    });
    onClose();
  };

  const formatTime = (hour: number, minutes: number) => {
    return `${hour}h${minutes ? minutes.toString().padStart(2, '0') : '00'}`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xl font-semibold">Nouvelle Réception</h2>
            <p className="text-sm text-gray-600 mt-1">
              {date} - {formatTime(hour, minutes)}
            </p>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Transporteur
            </label>
            {!showCustomInput ? (
              <div className="space-y-2">
                <select
                  className="w-full p-2 border rounded-md bg-white"
                  value={formData.transporteur}
                  onChange={(e) => setFormData(prev => ({ ...prev, transporteur: e.target.value }))}
                  required
                >
                  <option value="">Sélectionner un transporteur</option>
                  {transporters.map(transporteur => (
                    <option key={transporteur} value={transporteur}>
                      {transporteur}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setShowCustomInput(true)}
                  className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800"
                >
                  <Plus size={16} />
                  <span>Ajouter un autre transporteur</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <input
                  type="text"
                  className="w-full p-2 border rounded-md"
                  value={formData.transporteur}
                  onChange={(e) => setFormData(prev => ({ ...prev, transporteur: e.target.value }))}
                  placeholder="Nom du transporteur"
                  required
                />
                <button
                  type="button"
                  onClick={() => {
                    setShowCustomInput(false);
                    setFormData(prev => ({ ...prev, transporteur: '' }));
                  }}
                  className="text-sm text-blue-600 hover:text-blue-800"
                >
                  ← Retour à la liste
                </button>
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Référence
            </label>
            <input
              type="text"
              className="w-full p-2 border rounded-md"
              value={formData.reference}
              onChange={(e) => setFormData(prev => ({ ...prev, reference: e.target.value }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <textarea
              className="w-full p-2 border rounded-md"
              rows={3}
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
            />
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Ajouter
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}