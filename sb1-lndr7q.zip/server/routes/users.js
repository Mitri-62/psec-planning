import bcrypt from 'bcryptjs';
import db from '../db.js';
import { v4 as uuidv4 } from 'uuid';

export async function userRoutes(fastify) {
  fastify.get('/api/users', async (request, reply) => {
    try {
      const users = await db.all(
        `SELECT id, name, email, role, last_active 
         FROM users 
         WHERE company_id = ?`,
        [request.user.companyId]
      );
      return users;
    } catch (error) {
      console.error('Error fetching users:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });

  fastify.post('/api/users', async (request, reply) => {
    const { name, email, password, role } = request.body;

    try {
      const existingUser = await db.get(
        'SELECT id FROM users WHERE email = ?',
        [email]
      );

      if (existingUser) {
        return reply.code(400).send({ error: 'Email already exists' });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const id = uuidv4();

      await db.run(
        `INSERT INTO users (id, name, email, password, role, company_id) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [id, name, email, hashedPassword, role, request.user.companyId]
      );

      const user = await db.get(
        `SELECT id, name, email, role, last_active 
         FROM users 
         WHERE id = ?`,
        [id]
      );

      return user;
    } catch (error) {
      console.error('Error creating user:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });

  fastify.patch('/api/users/:id', async (request, reply) => {
    const { id } = request.params;
    const updates = request.body;

    try {
      const setClauses = [];
      const values = [];
      
      Object.entries(updates).forEach(([key, value]) => {
        if (key !== 'id' && key !== 'company_id') {
          setClauses.push(`${key} = ?`);
          values.push(value);
        }
      });

      if (setClauses.length === 0) {
        return reply.code(400).send({ error: 'No valid updates provided' });
      }

      values.push(id);
      values.push(request.user.companyId);

      await db.run(
        `UPDATE users 
         SET ${setClauses.join(', ')} 
         WHERE id = ? AND company_id = ?`,
        values
      );

      const user = await db.get(
        `SELECT id, name, email, role, last_active 
         FROM users 
         WHERE id = ? AND company_id = ?`,
        [id, request.user.companyId]
      );

      return user;
    } catch (error) {
      console.error('Error updating user:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });

  fastify.delete('/api/users/:id', async (request, reply) => {
    const { id } = request.params;

    try {
      await db.run(
        'DELETE FROM users WHERE id = ? AND company_id = ?',
        [id, request.user.companyId]
      );
      return { success: true };
    } catch (error) {
      console.error('Error deleting user:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });
}