import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Home, Maximize2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import TimeSlotGroup from '../components/TimeSlotGroup';
import AddReceptionModal from '../components/AddReceptionModal';
import { Reception } from '../types';

const TIME_SLOTS = Array.from({ length: 37 }, (_, i) => {
  const hour = Math.floor(i / 2) + 4;
  const minutes = (i % 2) * 30;
  return { hour, minutes };
});

interface PlanningProps {
  receptions: Reception[];
  transporters: string[];
  onAddReception: (data: Omit<Reception, 'id' | 'createdAt' | 'createdBy'>) => void;
  onUpdateStatus: (id: string, status: Reception['status']) => void;
  onUpdateNote: (id: string, note: string) => void;
  onDeleteReception: (id: string) => void;
}

export default function Planning({ 
  receptions,
  transporters,
  onAddReception, 
  onUpdateStatus, 
  onUpdateNote,
  onDeleteReception
}: PlanningProps) {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [modalData, setModalData] = useState<{ 
    date: Date;
    hour: number; 
    minutes: number; 
    position: number 
  } | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const adjustDate = (days: number) => {
    const newDate = new Date(selectedDate);
    newDate.setDate(selectedDate.getDate() + days);
    setSelectedDate(newDate);
  };

  const dates = Array.from({ length: 4 }, (_, i) => {
    const date = new Date(selectedDate);
    date.setDate(selectedDate.getDate() + i);
    return date;
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-full mx-auto p-2 2xl:p-4 3xl:p-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 2xl:p-6">
          <div className="flex items-center justify-between mb-4 2xl:mb-6">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl 2xl:text-4xl font-bold text-gray-900 dark:text-white">Planning PSEC</h1>
              <Link
                to="/"
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600"
              >
                <Home size={20} />
                <span>Retour à l'accueil</span>
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={toggleFullscreen}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
                title={isFullscreen ? "Quitter le mode plein écran" : "Mode plein écran"}
              >
                <Maximize2 size={24} className="text-gray-600 dark:text-gray-300" />
              </button>
              <button
                onClick={() => adjustDate(-4)}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
              >
                <ChevronLeft size={24} className="text-gray-600 dark:text-gray-300" />
              </button>
              <button
                onClick={() => adjustDate(4)}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full"
              >
                <ChevronRight size={24} className="text-gray-600 dark:text-gray-300" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4 mb-4">
            {dates.map((date) => (
              <div
                key={date.toISOString()}
                className="text-center font-medium text-gray-700 dark:text-gray-200 p-2 bg-gray-50 dark:bg-gray-700 rounded-lg 2xl:text-xl"
              >
                {date.toLocaleDateString('fr-FR', {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                })}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-4 gap-4 2xl:gap-8 overflow-auto max-h-[calc(100vh-12rem)]">
            {dates.map((date, dateIndex) => (
              <div key={date.toISOString()} className="space-y-4 2xl:space-y-6">
                {TIME_SLOTS.map(({ hour, minutes }) => (
                  <TimeSlotGroup
                    key={`${hour}:${minutes}`}
                    hour={hour}
                    minutes={minutes}
                    showLabel={dateIndex === 0}
                    receptions={receptions.filter(
                      r => r.date === date.toISOString().split('T')[0] &&
                          r.hour === hour &&
                          r.minutes === minutes
                    )}
                    onAddReception={(hour, minutes, position) => 
                      setModalData({ date, hour, minutes, position })
                    }
                    onConfirm={(id) => onUpdateStatus(id, 'confirmed')}
                    onMarkDelayed={(id) => onUpdateStatus(id, 'delayed')}
                    onMarkCompleted={(id) => onUpdateStatus(id, 'completed')}
                    onUpdateNote={onUpdateNote}
                    onUpdateStatus={onUpdateStatus}
                    onDeleteReception={onDeleteReception}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      {modalData && (
        <AddReceptionModal
          hour={modalData.hour}
          minutes={modalData.minutes}
          date={modalData.date.toLocaleDateString('fr-FR', {
            weekday: 'long',
            day: 'numeric',
            month: 'long'
          })}
          transporters={transporters}
          onClose={() => setModalData(null)}
          onAdd={(data) => {
            onAddReception({
              ...data,
              date: modalData.date.toISOString().split('T')[0],
              hour: modalData.hour,
              minutes: modalData.minutes,
              position: modalData.position,
              status: 'pending'
            });
            setModalData(null);
          }}
        />
      )}
    </div>
  );
}