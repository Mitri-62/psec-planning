import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from '../db.js';
import { v4 as uuidv4 } from 'uuid';

export async function authRoutes(fastify) {
  fastify.post('/api/auth/login', async (request, reply) => {
    const { email, password } = request.body;

    try {
      const user = await db.get(
        `SELECT users.*, companies.name as company_name 
         FROM users 
         JOIN companies ON users.company_id = companies.id 
         WHERE email = ?`,
        [email]
      );

      if (!user) {
        return reply.code(401).send({ error: 'Invalid credentials' });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return reply.code(401).send({ error: 'Invalid credentials' });
      }

      const token = jwt.sign(
        { 
          id: user.id, 
          email: user.email,
          companyId: user.company_id,
          role: user.role 
        },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
      );

      return { 
        token, 
        user: { 
          ...user, 
          password: undefined,
          company: {
            id: user.company_id,
            name: user.company_name
          }
        } 
      };
    } catch (error) {
      console.error('Login error:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });

  fastify.post('/api/auth/register-company', async (request, reply) => {
    const { companyName, adminEmail, adminPassword, adminName } = request.body;

    try {
      const hashedPassword = await bcrypt.hash(adminPassword, 10);
      const companyId = uuidv4();
      const userId = uuidv4();

      await db.run('BEGIN TRANSACTION');

      await db.run(
        'INSERT INTO companies (id, name) VALUES (?, ?)',
        [companyId, companyName]
      );

      await db.run(
        `INSERT INTO users (id, email, password, name, role, company_id) 
         VALUES (?, ?, ?, ?, 'admin', ?)`,
        [userId, adminEmail, hashedPassword, adminName, companyId]
      );

      await db.run('COMMIT');

      const token = jwt.sign(
        { 
          id: userId, 
          email: adminEmail,
          companyId: companyId,
          role: 'admin'
        },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
      );

      return { 
        token, 
        user: {
          id: userId,
          email: adminEmail,
          name: adminName,
          role: 'admin',
          company: {
            id: companyId,
            name: companyName
          }
        }
      };
    } catch (error) {
      await db.run('ROLLBACK');
      console.error('Registration error:', error);
      return reply.code(500).send({ error: 'Internal server error' });
    }
  });
}